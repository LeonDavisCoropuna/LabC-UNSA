#pragma once

#include "Persona.h"
using namespace std;

class Alumno : public Persona{
    public:
        void setAlumno();
        void mostrar();
        Alumno();
        ~Alumno();
};