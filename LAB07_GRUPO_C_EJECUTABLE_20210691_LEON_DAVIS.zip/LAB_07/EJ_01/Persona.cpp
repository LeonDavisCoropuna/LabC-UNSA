#include "Persona.h"
#include "iostream"

using namespace std;

Persona::Persona(){}
Persona::~Persona(){}