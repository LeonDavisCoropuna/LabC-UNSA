#include "Persona.h"
#include "Alumno.h"
#include<bits/stdc++.h>

using namespace std;

int main(){

    Alumno nuevo;
    nuevo.setAlumno();
    nuevo.mostrar();

    return 0;
}