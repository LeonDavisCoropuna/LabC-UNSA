#pragma once
#include <bits/stdc++.h>

using namespace std;

class Color{
    protected:
        int r,g,b;
    public:
        Color();
        ~Color();
};