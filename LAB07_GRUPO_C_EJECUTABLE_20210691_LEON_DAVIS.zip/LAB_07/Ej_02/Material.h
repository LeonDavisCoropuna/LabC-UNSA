#pragma once
#include <bits/stdc++.h>
#include "Color.h"

class Material : public Color{
    protected:
        string material;
    public:
        Material();
        ~Material();
};