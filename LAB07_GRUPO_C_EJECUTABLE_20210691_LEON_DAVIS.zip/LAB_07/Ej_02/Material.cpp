#include "Material.h"
#include <bits/stdc++.h>
using namespace std;

Material::Material(){}
Material::~Material(){}