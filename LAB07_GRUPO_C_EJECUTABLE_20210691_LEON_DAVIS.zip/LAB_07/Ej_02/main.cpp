#include <iostream>
#include "Obj.h"
using namespace std;

int main(){
    Objeto nuevo;
    nuevo.setObjeto();
    nuevo.mostrar();
    return 0;
}
