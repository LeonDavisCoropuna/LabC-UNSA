#include "Color.h"
#include <bits/stdc++.h>
using namespace std;

Color::Color(){}
Color::~Color(){}